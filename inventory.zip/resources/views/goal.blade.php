@extends('master')
@section('content')
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

    <!-- Icon Cards-->

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Add-Category
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="{{ url('add_goal') }}" method="POST">
            @csrf
          <div class="modal-body">
              <lebel>Goal-Amount</lebel>
             <input type="text" name="goal" value=""style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2-->
    @foreach ($goalpage as $key=>$goal )
    <div class="modal fade" id="exampleModal1{{ @$goal->id }}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal Edite</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form action="{{ url('goal_update',$goal->id) }}" method="POST">
              @csrf
            <div class="modal-body">
                <lebel>Goal-Amount</lebel>
                <input type="text" name="goal" value="{{ $goal->goal }}"style="width:90%">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Update</button>
          </form>
            </div>
          </div>
        </div>
      </div>
      @endforeach
    <!-- Area Chart Example-->


    <!-- DataTables Example -->
     <div class="mb-3 card"style="margin-top:60px">
      <div class="card-header">
        @if(session('success'))
        <div class="alert alert-success" role="alert">
            {{session('success')}}
        </div>
        <hr>
     @endif
     @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
        @endif
      @if(session('delete'))
        <div class="alert alert-danger" role="alert">
          {{session('delete')}}
        </div>
        <hr>
    @endif

    <form action="{{ url('GoalMonth_add') }}" method="POST">
        @csrf
        <i class="fas fa-table"></i>
        Data Table</div>
      <div class="card-body">
          <input type="date" name="goaldatemonthly" style="width:300px">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Total-Income</th>
                <th>Goal-This-Month</th>
                <th>Achived</th>
                <th>Action</th>
              </tr>
            </thead>

            @php
                 $sl=1;


            @endphp

            <tbody>
                {{--  @foreach($data as $key => $incomedata)  --}}
                @foreach($goalpage as $key => $goal)
                <input style="display:none" type="text" name="goal" value="{{ $goal->goal }}">
                <input style="display:none" type="text" name="achived" value="{{ $goal->id }}">





                {{-- @endforeach --}}

                @php

                $percentage = $totalincome;
                $totalWidth = $goal->goal;


                $percentage = (  $percentage / $totalWidth ) * 100;
                @endphp
              <tr>
                <td>{{ $sl++ }}</td>
                <td>{{ @$totalincome }}$</td>
                <td>{{ $goal->goal }}$</td>
                <td>{{@$percentage}}%</td>
                <td>
                    {{-- <a href="{{ url('goal_delete') }}/{{ $goal->id }}" class="btn btn-primary btn-sm"> <i class="fa fa-trash"></i></a> --}}
                    <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1{{ @$goal->id }}"><i class="fa fa-edit"></i></a>
                    <a href="{{ url('GoalMonthlyView') }}" class="btn btn-primary btn-sm"> <i class="fa fa-eye"></i></a>
                </td>
              </tr>

              @endforeach
              {{-- @endforeach --}}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <button class="btn btn-primary" type="submit">Submit</button>
</form>
    </div>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })

</script>

@endsection
