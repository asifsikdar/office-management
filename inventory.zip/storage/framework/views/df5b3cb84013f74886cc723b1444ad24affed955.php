<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Icon Cards-->

        <!-- Button trigger modal -->
        
            
        

        
        
            
                
                    
                        
                        
                            
                        
                    
                    
                        
                        
                            
                            
                            
                            
                            
                            
                            
                            
                        
                        
                            
                            
                    
                
            
        
    



    


    <!-- Modal 2-->
    <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="modal fade" id="exampleModal1<?php echo e(@$sal->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">--}}
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Modal Edite</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="<?php echo e(url('update_month_income',$sal->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <lebel>Category</lebel>
                            <input type="date" name="income_month" value="<?php echo e(@$sal->income_month); ?>"placeholder="Cetegory"style="width:90%"><br><br>
                            <input type="text" name="income" value="<?php echo e(@$sal->income); ?>"placeholder="Cetegory"style="width:90%">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary">Update</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <!-- Area Chart Example-->
    
        
    

    <!-- DataTables Example -->
    <div class="mb-3 card"style="margin-top:60px">
        <div class="card-header">

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <hr>
            <?php endif; ?>



            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        </div>
        
            
            <h3><?php echo e($salary['0']->income_month); ?></h3>
            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Income-Month</th>
                            <th>Income-Amount</th>
                            
                            <th>Action</th>
                        </tr>
                        </thead>

                        <?php
                            $sl=1;
                        ?>
                        <tbody>

                        <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                                

                                <tr>
                                <td><?php echo e($sl++); ?></td>
                                <td><?php echo e($salary->income_month); ?></td>
                                <td><?php echo e($salary->income); ?></td>
                                

                              <td>
                                <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1<?php echo e(@$sal->id); ?>"><i class="fa fa-edit"></i></a>
                              </td>

                                

                                
                                
                                
                                    

                                    
                                    <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1<?php echo e(@$emp->id); ?>"><i class="fa fa-edit"></i></a>
                                
                            </tr>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
        
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>

    </div>
    <script>
        $('#myModal').on('shown.bs.modal', function () {
            $('#myInput').trigger('focus')
        })

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\single_income_data.blade.php ENDPATH**/ ?>