
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">

        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Overview</li>
        </ol>

        <!-- Icon Cards-->

        <!-- Button trigger modal -->
        
            
        

        
        
            
                
                    
                        
                        
                            
                        
                    
                    
                        
                        
                            
                            
                            
                            
                            
                            
                            
                            
                        
                        
                            
                            
                    
                
            
        
    



    


    <!-- Modal 2-->
    
        
            
                
                    
                        
                        
                            
                        
                    
                    
                        
                        
                            
                            
                            
                            
                        
                        
                            
                            
                    
                
            
        
        

    
    <br><br>
    <!-- Area Chart Example-->
    <div class="mb-3 card">
        <div class="card-header">
            <i class="fas fa-chart-area"></i>
            Area Chart Example</div>
        <div class="card-body">
            <canvas id="myAreaChart" width="100%" height="15"></canvas>
        </div>
        
    </div>

    <!-- DataTables Example -->
    <div class="mb-3 card"style="margin-top:60px">
        <div class="card-header">

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <hr>
            <?php endif; ?>



            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        </div>
        <form action="<?php echo e(url('update_month_record')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <h3><?php echo e($salary['0']->salary_month); ?></h3>
            <input type="hidden" name="mm" value="<?php echo e($salary['0']->salary_month); ?>">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Employee Name</th>
                            <th>Employee Email</th>
                            
                            <th>Status</th>
                            <th>Salary-Amount</th>
                            
                            <th>Action</th>
                        </tr>
                        </thead>

                        <?php
                            $sl=1;
                        ?>
                        <tbody>

                        <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = App\Models\SalaryModel::where('id',$salary->employee_id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                

                                <tr>
                                <td><?php echo e($sl++); ?></td>
                                <td><?php echo e($emp->name); ?></td>
                                <td><?php echo e($emp->email); ?></td>
                                <input type="hidden" name="employee_id[]" value="<?php echo e($salary->id); ?>">
                                <input type="hidden" name="payment[]" value="<?php echo e($salary->salary_amount); ?>">
                                <input type="hidden" name="salary_status[]" value="<?php echo e($salary->status); ?>">

                                <td>

                                    <?php if($salary->salary_status==1): ?>
                                        <a class="btn btn-primary">Pending</a>
                                    <?php else: ?>
                                        <a class="btn btn-primary">Paid</a>
                                    <?php endif; ?>

                                </td>

                                <td><?php echo e($emp->salary_amount); ?></td>

                                
                                
                                <td>
                                    <?php if($salary->salary_status==1): ?>
                                    <input type="checkbox" name="status_update[<?php echo e($salary->employee_id); ?>]" id="salary_status" value="update_status">
                                <?php else: ?>
                                        <span class="badge badge-success">Payment Paid Successfully!</span>
                                        <?php endif; ?>
                                    

                                    
                                    
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-primary" type="submit">Update</button>
        </form>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>

    </div>
    <script>
        $('#myModal').on('shown.bs.modal', function () {
            $('#myInput').trigger('focus')
        })

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\month_wise_salary_view.blade.php ENDPATH**/ ?>