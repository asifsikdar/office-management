<?php $__env->startSection('content'); ?>
    <!-- DataTables Example -->
    <div class="mb-3 card"style="margin-top:60px">
        <div class="card-header">

            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('success')); ?>

                </div>
                <hr>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>


        </div>
        <form action="#" method="POST">
            <?php echo csrf_field(); ?>
            
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Id</th>
                            <th>Goal-Month</th>
                            <th>Expense_month</th>
                            <th>Action</th>
                        </tr>
                        </thead>

                        <?php
                            $sl=1;
                        ?>
                        <tbody>

                         
                            <tr>
                                 <td><?php echo e($sl++); ?></td>

                                 <td></td>
                                 <td></td>

                                
                                
                                


                                <td>
                                    
                                    <a href="" class="btn btn-primary btn-sm"> <i class="fa fa-eye"></i></a>
                                    <a href="" class="btn btn-primary btn-sm"> <i class="fa fa-trash"></i></a>
                                </td>
                            </tr>
                         
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-primary" type="submit">Submit</button>
        </form>
        <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>

    </div>
    <script>
        $('#myModal').on('shown.bs.modal', function () {
            $('#myInput').trigger('focus')
        })

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\goal_monthly_record.blade.php ENDPATH**/ ?>