<?php $__env->startSection('content'); ?>

<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

    <!-- Icon Cards-->



    <!-- Modal -->


    <!-- Modal 2-->
    <?php $__currentLoopData = $income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="exampleModal1<?php echo e(@$inc->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal Edite</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(url('income_edit',$inc->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Category</lebel>
              <select style="width: 90%" name="mother_company">Category
                <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->mother_company); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
               <select style="width: 90%" name="children_company">Category
                <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->children_company); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
               <lebel>Amount</lebel>
            <input type="text" name="income_amount" value="<?php echo e($inc->income_amount); ?>"style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  <!-- Modal 3 -->
  <?php $__currentLoopData = $income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="modal fade" id="exampleModal2<?php echo e($inc->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>


        <form action="<?php echo e(url('/donate')); ?>" method="POST">
          <?php echo csrf_field(); ?>
        <div class="modal-body">
            <lebel>Main</lebel>
           <select style="width: 90%" name="category">
            <?php $__currentLoopData = App\Models\IncomeModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->get_category['mother_company']); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
          <br><br>
           <lebel>Form</lebel>
           <select style="width: 90%" name="child_category_form">
            <?php $__currentLoopData = App\Models\IncomeModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->children_company); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           <br><br>
           <lebel>To</lebel>
           <select style="width: 90%" name="children_company_to">
            <?php $__currentLoopData = App\Models\IncomeModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->children_company); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
          <lebel>Donate-Amount</lebel>
          <input type="hidden" name="status">

          <input type="hidden" name="Getid" value="<?php echo e($inc->id); ?>">
          <input type="hidden" name="ammount" value="<?php echo e($inc->income_amount); ?>">

          <input type="text" name="income_amount" placeholder="amount"style="width:90%">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
      </form>


        </div>
      </div>
    </div>


  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <!-- End Modal 3 -->


    <!-- Area Chart Example-->
     <div class="mb-3 card">
      <div class="card-header">
        <i class="fas fa-chart-area"></i>
        Area Chart Example</div>
      <div class="card-body">
        <canvas id="myAreaChart" width="100%" height="15"></canvas>
      </div>
      <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>

    <!-- DataTables Example -->
     <div class="mb-3 card"style="margin-top:60px">
      <div class="card-header">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <hr>
     <?php endif; ?>
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
      <?php if(session('delete')): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e(session('delete')); ?>

        </div>
        <hr>
    <?php endif; ?>
    <form action="<?php echo e(route('MonthIncome')); ?>" method="POST">
        <?php echo csrf_field(); ?>
    <input type="date" name="income_month" style="width:500px;">

        <i class="fas fa-table"></i>
        </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Mother-Company</th>
                <th>Children-Company</th>
                <th>Income-Amount</th>
                <th>Donation In</th>
                <th>Donation Out</th>
                <th>Action</th>
              </tr>

            </thead>
            
            <?php
                $sl=1;
                $donation_in=0;
            ?>
            <tbody>
                <?php $__currentLoopData = $income; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php

                $donation_in = App\Models\Donate::where('donation_in_id',$inc->id)->get();
                $donation_out = App\Models\Donate::where('donation_out_id',$inc->id)->get();

               ?>

                <input style="display:none" type="text" name="employee_id[]" value="<?php echo e($inc->id); ?>">

                <input style="display:none" type="text" name="income_status[]" value="<?php echo e($inc->status); ?>">
               <input style="display:none" type="text" name="income[]" value="<?php echo e($inc->income_amount); ?>">
              <tr>

                <td><?php echo e($sl++); ?></td>

                
                <td><?php echo e($inc->get_category['mother_company']); ?></td>
                <td><?php echo e($inc->children_company); ?></td>




                <td><?php echo e($inc->income_amount); ?></td>
                <td><?php $__currentLoopData = $donation_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(@$all->donation_in_ammount); ?>+ <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td><?php $__currentLoopData = $donation_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $all_int): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e(@$all_int->donation_out_ammount); ?>- <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

                <td style="text-align:center">

                    
                    
                    <a href="#"  data-toggle="modal" data-target="#exampleModal2<?php echo e($inc->id); ?>" class="btn btn-primary btn-sm"><i class="fas fa-donate"></i></a>
                    
                </td>


              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

      
    </div>
    <button class="btn btn-primary" type="submit" style="form-control">Submit</button>
</form>
    </div>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\donation_page.blade.php ENDPATH**/ ?>