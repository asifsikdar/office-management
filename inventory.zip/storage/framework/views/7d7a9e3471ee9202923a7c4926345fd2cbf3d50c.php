<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

    <!-- Icon Cards-->

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Add-Category
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(route('add_salary')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Employee Name</lebel>
            <input type="text" name="name" value=""placeholder="Employee Name"style="width:90%">
            <lebel>Employee Email</lebel>
            <input type="text" name="email" value=""placeholder="Employee Email"style="width:90%">
            <lebel>Salary-Amount</lebel>
            <input type="text" name="salary_amount" value=""placeholder="Salary-Amount"style="width:90%">
            <lebel>Date</lebel>
            <input type="date" name="start_date" value=""placeholder="Salary-Amount"style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2-->
    <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="exampleModal1<?php echo e(@$sal->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal Edite</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(route('edit',$sal->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Category</lebel>
            <input type="text" name="name" value="<?php echo e(@$sal->name); ?>"placeholder="Cetegory"style="width:90%">
            <input type="text" name="email" value="<?php echo e(@$sal->email); ?>"placeholder="Cetegory"style="width:90%">
            <input type="text" name="salary_amount" value="<?php echo e(@$sal->salary_amount); ?>"placeholder="Cetegory"style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br><br>
    <!-- Area Chart Example-->
     <div class="mb-3 card">
      <div class="card-header">
        <i class="fas fa-chart-area"></i>
        Area Chart Example</div>
      <div class="card-body">
        <canvas id="myAreaChart" width="100%" height="15"></canvas>
      </div>
      
    </div>

    <!-- DataTables Example -->
     <div class="mb-3 card"style="margin-top:60px">
      <div class="card-header">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <hr>
     <?php endif; ?>
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
      <?php if(session('delete')): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e(session('delete')); ?>

        </div>
        <hr>
    <?php endif; ?>
        <i class="fas fa-table"></i>
        Data Table</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Employee Name</th>
                <th>Employee Email</th>
                
                <th>Status</th>
                <th>Salary-Amount</th>
                <th>Date-Time</th>
                <th>Action</th>
              </tr>
            </thead>

            <?php
                $sl=1;
            ?>
            <tbody>
                <?php $__currentLoopData = $salary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $salary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($sl++); ?></td>
                <td><?php echo e($salary->name); ?></td>
                <td><?php echo e($salary->email); ?></td>

                <td>

                    <?php if($salary->status==1): ?>
                    <a class="btn btn-primary">Pending</a>
                    <?php else: ?>
                    <a class="btn btn-primary">Paid</a>
                    <?php endif; ?>





                </td>

                <td><?php echo e($salary->salary_amount); ?></td>
                <?php if($salary->status==1): ?>
                <td></td>
                <?php else: ?>
                <td><?php echo e($salary->updated_at->format('d-m-y')); ?></td>
                <?php endif; ?>
                <td>
                    <a href="<?php echo e(url('/salary_delete')); ?>/<?php echo e($salary->id); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-trash"></i></a>
                    <a href="<?php echo e(url('/update_status',$salary->id)); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-plus"></i></a>
                    <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1<?php echo e(@$salary->id); ?>"><i class="fa fa-edit"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
      <div class="card-footer small text-muted">Updated yesterday at 11:59 PM</div>
    </div>

    </div>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\previews_salary.blade.php ENDPATH**/ ?>