<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

    <!-- Icon Cards-->

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Add-Category
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(url('add_goal')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Goal-Amount</lebel>
             <input type="text" name="goal" value=""style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2-->
    <?php $__currentLoopData = $goalpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="exampleModal1<?php echo e(@$goal->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Modal Edite</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <form action="<?php echo e(url('goal_update',$goal->id)); ?>" method="POST">
              <?php echo csrf_field(); ?>
            <div class="modal-body">
                <lebel>Goal-Amount</lebel>
                <input type="text" name="goal" value="<?php echo e($goal->goal); ?>"style="width:90%">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" class="btn btn-primary">Update</button>
          </form>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Area Chart Example-->


    <!-- DataTables Example -->
     <div class="mb-3 card"style="margin-top:60px">
      <div class="card-header">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <hr>
     <?php endif; ?>
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
      <?php if(session('delete')): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e(session('delete')); ?>

        </div>
        <hr>
    <?php endif; ?>

    <form action="<?php echo e(url('GoalMonth_add')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <i class="fas fa-table"></i>
        Data Table</div>
      <div class="card-body">
          <input type="date" name="goaldatemonthly" style="width:300px">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Total-Income</th>
                <th>Goal-This-Month</th>
                <th>Achived</th>
                <th>Action</th>
              </tr>
            </thead>

            <?php
                 $sl=1;


            ?>

            <tbody>
                
                <?php $__currentLoopData = $goalpage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <input style="display:none" type="text" name="goal" value="<?php echo e($goal->goal); ?>">
                <input style="display:none" type="text" name="achived" value="<?php echo e($goal->id); ?>">





                

                <?php

                $percentage = $totalincome;
                $totalWidth = $goal->goal;


                $percentage = (  $percentage / $totalWidth ) * 100;
                ?>
              <tr>
                <td><?php echo e($sl++); ?></td>
                <td><?php echo e(@$totalincome); ?>$</td>
                <td><?php echo e($goal->goal); ?>$</td>
                <td><?php echo e(@$percentage); ?>%</td>
                <td>
                    
                    <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1<?php echo e(@$goal->id); ?>"><i class="fa fa-edit"></i></a>
                    <a href="<?php echo e(url('GoalMonthlyView')); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-eye"></i></a>
                </td>
              </tr>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
            </tbody>
          </table>
        </div>
      </div>
    </div>
  <button class="btn btn-primary" type="submit">Submit</button>
</form>
    </div>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\goal.blade.php ENDPATH**/ ?>