<?php $__env->startSection('content'); ?>
<div class="container-fluid">

    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
      </li>
      <li class="breadcrumb-item active">Overview</li>
    </ol>

    <!-- Icon Cards-->

    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
      Add-Category
    </button>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(route('expense')); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Mother-Company</lebel>
              <select style="width: 90%" name="mother_company">Category
                <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->mother_company); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>
              <br><br>

              <lebel>Expense-Category</lebel>
              <input type="text" name="expense_category" value=""style="width:90%">
               <lebel>Amount</lebel>
            <input type="text" name="expense_amount" value=""style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Save</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <!-- Modal 2-->
    <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="exampleModal1<?php echo e(@$exp->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal Edit</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <form action="<?php echo e(url('expense_update',$exp->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
          <div class="modal-body">
              <lebel>Category</lebel>
              <select style="width: 90%" name="mother_company">Category
                <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->mother_company); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>

               <lebel>Expense-Category</lebel>
               <input type="text" name="expense_category" value="<?php echo e($exp->expense_category); ?>"style="width:90%">
                <lebel>Amount</lebel>
             <input type="text" name="expense_amount" value="<?php echo e($exp->expense_amount); ?>"style="width:90%">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
          </div>
        </div>
      </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div id="container"></div>


  

    <!-- DataTables Example -->
     <div class="mb-3 card"style="margin-top:60px">
      <div class="card-header">
        <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
        <hr>
     <?php endif; ?>
     <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
      <?php if(session('delete')): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo e(session('delete')); ?>

        </div>
        <hr>
    <?php endif; ?>
    <form action="<?php echo e(url('expense_month')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <input type="date" name="expense_month" style="width:500px;">
        <i class="fas fa-table"></i>
        Data Table</div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
            <thead>
              <tr>
                <th>Id</th>
                <th>Mother-Company</th>
                <th>Expense-Category</th>
                <th>Expense-Amount</th>
                <th>Action</th>
              </tr>
            </thead>

            <?php
                $sl=1;
            ?>
            <tbody>
                <?php $__currentLoopData = $expense; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <input style="display:none" type="text" name="employee_id[]" value="<?php echo e($exp->id); ?>">
                 <input style="display:none" type="text" name="expense_status[]" value="<?php echo e($exp->expense_status); ?>">
                 <input style="display:none" type="text" name="mother_company[]" value="<?php echo e($exp->get_category['mother_company']); ?>">
                 <input style="display:none" type="text" name="expense_category[]" value="<?php echo e($exp->expense_category); ?>">
                 <input style="display:none" type="text" name="expense_amount[]" value="<?php echo e($exp->expense_amount); ?>">
                 
              <tr>
                <td><?php echo e($sl++); ?></td>
                <td><?php echo e($exp->get_category['mother_company']); ?></td>
                <td><?php echo e($exp->expense_category); ?></td>
                <td><?php echo e($exp->expense_amount); ?></td>
                <td>
                    <a href="<?php echo e(url('expense_delete')); ?>/<?php echo e($exp->id); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-trash"></i></a>
                    <a href="#" class="btn btn-primary btn-sm"  data-toggle="modal" data-target="#exampleModal1<?php echo e(@$exp->id); ?>"><i class="fa fa-edit"></i></a>
                    <a href="<?php echo e(url('expense_month_page')); ?>" class="btn btn-primary btn-sm"> <i class="fa fa-eye"></i></a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
    <button class="btn btn-primary" type="submit" style="form-control">Submit</button>
</form>
    </div>
<script>
    $('#myModal').on('shown.bs.modal', function () {
        $('#myInput').trigger('focus')
      })

</script>

<?php
$users = App\Models\ExpenseRecordModel::select(DB::raw("sum(expense_amount) as count"))
->whereYear('expense_month', date('Y'))
->groupBy(DB::raw("Month(expense_month)"))
->pluck('count');

$userss = App\Models\ExpenseRecordModel::get();





?>




<script type="text/javascript">

    var users =  <?php echo json_encode($users) ?>;


    Highcharts.chart('container', {
        title: {
            text: 'Expense Growth, 2021'
        },
        subtitle: {
            text: 'Themefisher'
        },
         xAxis: {
            categories:['January','February','March','April','May','Jun','July','September','October']

        },
        yAxis: {
            title: {
                text: 'Number of the Expense'
            }
        },
        legend: {
            layout: 'vertical',
            align: 'right',
            verticalAlign: 'middle'
        },
        plotOptions: {
            series: {
                allowPointSelect: true
            }
        },
        series: [{
            name: 'Expense-Total',
            data: users
        }],
        responsive: {
            rules: [{
                condition: {
                    maxWidth: 500
                },
                chartOptions: {
                    legend: {
                        layout: 'horizontal',
                        align: 'center',
                        verticalAlign: 'bottom'
                    }
                }
            }]
        }
});
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\expense.blade.php ENDPATH**/ ?>