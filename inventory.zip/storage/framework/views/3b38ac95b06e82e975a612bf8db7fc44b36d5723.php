<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
    <hr>
  <?php endif; ?>
<!-- Breadcrumbs-->
<ol class="breadcrumb">
  <li class="breadcrumb-item">
    <a href="#">Dashboard</a>
  </li>
  <li class="breadcrumb-item active">Overview</li>
</ol>


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="POST">
        <?php echo csrf_field(); ?>
      <div class="modal-body">
          <lebel>Category</lebel>
        <input type="text" name="category" value=""placeholder="Cetegory"style="width:90%">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
    </form>
      </div>
    </div>
  </div>
</div>

<!--End Modal -->

<!-- Modal 2 -->

<div class="modal fade" id="exampleModal1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('add_expense')); ?>" method="POST">
          <?php echo csrf_field(); ?>
        <div class="modal-body">
            <lebel>Category</lebel>
            <select style="width: 90%" name="category">Category
                <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->category); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </select>

            <input type="text" name="expense_amount" value=""placeholder="expense_amount"style="width:90%">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
      </form>
        </div>
      </div>
    </div>
  </div>

  <!-- End Modal 2 -->


  <!-- Modal 3 -->
  <div class="modal fade" id="exampleModal2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="<?php echo e(route('add_income')); ?>" method="POST">
          <?php echo csrf_field(); ?>
        <div class="modal-body">
            <lebel>Category</lebel>
           <select style="width: 90%" name="mother_company">Category
            <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->mother_company); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </select>
           <lebel>Category</lebel>
           <select style="width: 90%" name="children_company">Category
            
            <option>Sitepines</option>
            <option>Themefisher</option>
            <option>Gethugo-theme</option>
               
           </select>
          <lebel>Amount</lebel>
          <input type="hidden" name="status">
          <input type="text" name="income_amount" placeholder="amount"style="width:90%">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          <button type="submit" class="btn btn-primary">Save</button>
      </form>
        </div>
      </div>
    </div>
  </div>

  <!-- End Modal 3 -->


<!-- Icon Cards-->
<div class="row">
  <div class="mb-3 col-xl-3 col-sm-6">
    <div class="text-white card bg-primary o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-comments"></i>
        </div>
        <div class="mr-5">Total Income </div>
        <h3><?php echo e(@$totalincome); ?> $</h3>
      </div>
      <a class="clearfix text-white card-footer small z-1" href="<?php echo e(url('income-page')); ?>">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fas fa-angle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="mb-3 col-xl-3 col-sm-6">
    <div class="text-white card bg-warning o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-list"></i>
        </div>
        <div class="mr-5">Expense Total</div>

        <h3><?php echo e($totalall); ?> $</h3>
      </div>
      <a class="clearfix text-white card-footer small z-1" href="<?php echo e(url('expense')); ?>">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fas fa-angle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="mb-3 col-xl-3 col-sm-6">
    <div class="text-white card bg-success o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-shopping-cart"></i>
        </div>
        <div class="mr-5">Goal</div>
        <?php $__currentLoopData = App\Models\GoalModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <h4>Goal-This-Month</h4>
          <h3><?php echo e($goal->goal); ?>$</h3>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <a class="clearfix text-white card-footer small z-1" href="<?php echo e(url('view_goal_page')); ?>">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fas fa-angle-right"></i>
        </span>
      </a>
    </div>
  </div>
  <div class="mb-3 col-xl-3 col-sm-6">
    <div class="text-white card bg-danger o-hidden h-100">
      <div class="card-body">
        <div class="card-body-icon">
          <i class="fas fa-fw fa-life-ring"></i>
        </div>
        <div class="mr-5"></div>
      </div>
      <a class="clearfix text-white card-footer small z-1" href="#">
        <span class="float-left">View Details</span>
        <span class="float-right">
          <i class="fas fa-angle-right"></i>
        </span>
      </a>
    </div>
  </div>
</div>


<div class="row">
    <div class="mb-3 col-xl-4 col-sm-6">
      <div class="text-white card bg-primary o-hidden h-100">
        <div class="card-body">
          <div class="card-body-icon">
            <i class="fas fa-fw fa-comments"></i>
          </div>
          <div class="mr-5"></div>
          <lebel>Income</lebel>
          <hr style="background-color: rgb(15, 15, 15)">
          <?php $__currentLoopData = App\Models\IncomeModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $income): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mr-5"><?php echo e($income->get_category->mother_company); ?>----<?php echo e($income->children_company); ?>---
              <?php echo e($income->income_amount); ?>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="clearfix text-white card-footer small z-1" href="#">
          <span class="float-left">View Details</span>
          <span class="float-right">
            <i class="fas fa-angle-right"></i>
          </span>
        </a>
      </div>
      <a href="#" class="btn btn-primary btn-sm" style="margin-top: 10px;margin-left:140px;margin-button:20px;" data-toggle="modal" data-target="#exampleModal2"><i class="fa fa-plus"></i></a>
    </div>


    <div class="mb-3 col-xl-4 col-sm-6">
      <div class="text-white card bg-warning o-hidden h-100">
        <div class="card-body">
          <div class="card-body-icon">
            <i class="fas fa-fw fa-list"></i>
          </div>
          <div class="mr-5"></div>
          <lebel>Expense</lebel>
          <hr style="background-color: rgb(15, 15, 15)">
          <?php $__currentLoopData = App\Models\ExpenseModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mr-5"><?php echo e($expense->get_category['mother_company']); ?>----<?php echo e($expense->expense_category); ?>

              <?php echo e($expense->expense_amount); ?>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          <p>Salary-Amount-Total ---- <?php echo e($totalesalary); ?> $</p>
        </div>
        <a class="clearfix text-white card-footer small z-1" href="#">
          <span class="float-left">View Details</span>
          <span class="float-right">
            <i class="fas fa-angle-right"></i>
          </span>
        </a>
      </div>
      <a href="#" class="btn btn-primary btn-sm" style="margin-top: 10px;margin-left:140px;margin-button:20px;"  data-toggle="modal" data-target="#exampleModal1"><i class="fa fa-plus"></i></a>
    </div>


    <div class="mb-3 col-xl-4 col-sm-6">
      <div class="text-white card bg-success o-hidden h-100">
        <div class="card-body">
          <div class="card-body-icon">
            <i class="fas fa-fw fa-shopping-cart"></i>
          </div>
          <lebel>Category</lebel>
          <hr style="background-color: rgb(15, 15, 15)">
          <?php $__currentLoopData = App\Models\CategoryModel::get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="mr-5"><?php echo e($cat->mother_company,$cat->id); ?>

              ----<?php echo e($cat->children_company,$cat->id); ?>

          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <a class="clearfix text-white card-footer small z-1" href="#">
          <span class="float-left">View Details</span>
          <span class="float-right">
            <i class="fas fa-angle-right"></i>
          </span>
        </a>
      </div>
      <a href="#" class="btn btn-primary btn-sm" style="margin-top: 10px;margin-left:140px;margin-button:20px;"  data-toggle="modal" data-target="#exampleModal"><i class="fa fa-plus" ></i></a>
    </div>




<!-- DataTables Example -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\inventory1\resources\views\dashboard.blade.php ENDPATH**/ ?>